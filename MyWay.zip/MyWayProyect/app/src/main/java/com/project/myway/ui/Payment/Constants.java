package com.project.myway.ui.Payment;

import com.google.android.gms.wallet.WalletConstants;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Constants {

    public static final int PAYMENTS_ENVIRONMENT = WalletConstants.ENVIRONMENT_TEST;


    public static final String SUPPORTED_NETWORKS = "VISA";

    public static final String SUPPORTED_METHODS = "PAN_ONLY";


    public static final String COUNTRY_CODE = "US";

    public static final String CURRENCY_CODE = "USD";

    public static final String PAYMENT_GATEWAY_TOKENIZATION_NAME = "MyTokenization";

    public static final HashMap<String, String> PAYMENT_GATEWAY_TOKENIZATION_PARAMETERS =
            new HashMap<String, String>() {
                {
                    put("gateway", PAYMENT_GATEWAY_TOKENIZATION_NAME);
                    put("gatewayMerchantId", "exampleGatewayMerchantId");
                    // Your processor may require additional parameters.
                }
            };

    private Constants() {}

}
