package com.project.myway.ui.Carrear;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.project.myway.MapsActivity;
import com.project.myway.MiUbicacion_Activity;
import com.project.myway.R;

public class CarrearFragment extends Fragment {

    Button btn_destino, btn_miubicacion;

    @Override
    public void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        btn_destino = (Button) btn_destino.findViewById(R.id.btn_destino);
        btn_miubicacion = (Button) btn_miubicacion.findViewById(R.id.btn_miubicacion);
        btn_destino.setOnClickListener(new View.OnClickListener(){

            @Override
            public  void onClick (View v)  {
                Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(intent);

            }
        });




        btn_miubicacion.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), MiUbicacion_Activity.class);
                startActivity(intent);
            }
        });





    }


   // private CarrearViewModel carrearViewModel;

   // public View onCreateView(@NonNull LayoutInflater inflater,
     //                        ViewGroup container, Bundle savedInstanceState) {
       // return inflater.inflate(R.layout.fragment_carrear, container, false);
    //}


}