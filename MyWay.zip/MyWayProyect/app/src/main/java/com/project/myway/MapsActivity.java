package com.project.myway;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.Locale;


public class MapsActivity extends AppCompatActivity implements GoogleMap.OnMarkerDragListener,OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private GoogleMap mMap;
    private Marker markerTegucigalpa, markerUJCV, markerAeropuertoToncontin, markerMallMultiplaza,
            markerCityMall, markerColKennedy, markerColTiloarque, markerColoniaMirflores, markerColoniaUvas , markerDrag;
    public static int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 101;
    public  boolean mLocationPermissionGranted;
    FusedLocationProviderClient fLPC;
    private  String TAG;
    Location location;
    LocationRequest LocationRequest;
    LocationCallback LocationCallback;
    boolean requestingLocationUpdates;


    LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
            .addLocationRequest(LocationRequest);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        Places.initialize(getApplicationContext(), "AIzaSyCFqrqKNo6tF8lXg8sB5dfrl05nhWTJELw");

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        PlacesClient placesClient = Places.createClient(this);
        FusedLocationProviderClient mFLPC = LocationServices.getFusedLocationProviderClient(this);

        SupportMapFragment mFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        LocationSettingsRequest.Builder builder1 = new LocationSettingsRequest.Builder();


        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());

        createLocationRequest();
    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //Ciudad de Tegucigalpa
        LatLng tegucigalpa = new LatLng(14.0626436,-87.2203804);
        markerTegucigalpa =  googleMap.addMarker((new MarkerOptions().position(tegucigalpa).title("Ciudad de Tegucigalpa")));

        //UJCV
        LatLng UJCV = new LatLng(14.0821764,-87.200292);
        markerUJCV = googleMap.addMarker(new MarkerOptions().position(UJCV).draggable(true).title("Universidad Jose Cecilio Del Valle")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));


        //Aeropuerto Toncontin
        LatLng AeropuertoToncontin = new LatLng(14.0603738,-87.2193355);
        markerAeropuertoToncontin = googleMap.addMarker(new MarkerOptions().position(AeropuertoToncontin).draggable(true).title("Aeropuerto Intercacional Toncontin")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));

        //Mall Multiplaza
        LatLng MallMultiplaza = new LatLng(14.0879628,-87.1829934);
       markerMallMultiplaza = googleMap.addMarker(new MarkerOptions().position(MallMultiplaza).draggable(true).title("Mall Multiplaza")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));


        //City Mall
        LatLng CityMall = new LatLng(14.0626436,-87.2203804);
       markerCityMall = googleMap.addMarker(new MarkerOptions().position(CityMall).draggable(true).title("City Mall")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));


        //Colonia Kennedy
        LatLng ColKennedy = new LatLng(-87.1800261,14.0649692);
        markerColKennedy = googleMap.addMarker(new MarkerOptions().position(ColKennedy).draggable(true).title("Colonia Kennedy")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));


        //Lomas de Tiloarque
        LatLng LomasTiloarque = new LatLng(14.0756024,-87.222527);
       markerColTiloarque = googleMap.addMarker(new MarkerOptions().position(LomasTiloarque).draggable(true).title("Col. Lomas de Tiloarque")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)));


        //Col. Miraflores
        LatLng ColMiraflores= new LatLng(14.0738102,-87.1864807);
        markerColoniaMirflores = googleMap.addMarker(new MarkerOptions().position(ColMiraflores).draggable(true).title("Colonia Miraflores")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));



        //Las Uvas
        LatLng LasUvas = new LatLng(14.0392125,-87.2349006);
        markerColoniaUvas = googleMap.addMarker(new MarkerOptions().position(LasUvas).draggable(true).title("Residencial Las Uvas")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));


//Camara
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(tegucigalpa,7));

        //Click en el Marcador
        googleMap.setOnMarkerClickListener(this);

        //Arrastrar el Marcador
        googleMap.setOnMarkerDragListener(this);

       // mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        updateLocationUI();
        getDeviceLocation();

    }

    private void getLocationPermission() {
        /*
         * Request location permission, so that we can get the location of the
         * device. The result of the permission request is handled by a callback,
         * onRequestPermissionsResult.
         */
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;

        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        mMap.setMyLocationEnabled(false);
        if (requestCode == PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION) {// If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mMap.setMyLocationEnabled(true);
            }
        }
        updateLocationUI();
    }

    private void updateLocationUI() {
        if (mMap == null) {
            return;
        }
        try {
            if (mLocationPermissionGranted) {
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setMyLocationButtonEnabled(true);
                getDeviceLocation();
            } else {
                mMap.setMyLocationEnabled(false);
                mMap.getUiSettings().setMyLocationButtonEnabled(false);
                fLPC.getLastLocation();
                getLocationPermission();
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void getDeviceLocation() {
        try {
            if (mLocationPermissionGranted) {
                Task<Location> locationResult = fLPC.getLastLocation();
                locationResult.addOnCompleteListener(new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful()) {
                            // Set the map's camera position to the current location of the device.
                            Location location = task.getResult();
                            LatLng currentLatLng = new LatLng(location.getLatitude(),
                                    location.getLongitude());
                            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(currentLatLng,
                                    16);
                            mMap.moveCamera(update);
                        }
                    }
                });
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    protected void createLocationRequest() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (requestingLocationUpdates) {
            startLocationUpdates();
        }
    }

    private void startLocationUpdates() {
        fLPC.requestLocationUpdates(LocationRequest,
                LocationCallback,
                null /* Looper */);
    }


    public void onClick(View view) {

    }

    @Override
    public boolean onMarkerClick(Marker marker) {


        if(marker.equals(markerTegucigalpa)){
            String lat,lang;

            lat = Double.toString(markerTegucigalpa.getPosition().latitude);
            lang = Double.toString(markerTegucigalpa.getPosition().longitude);

            Toast.makeText(this,"Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();
        }
        else if (marker.equals(markerUJCV)){
            String lat,lang;

            lat = Double.toString(markerUJCV.getPosition().latitude);
            lang = Double.toString(markerUJCV.getPosition().longitude);

            Toast.makeText(this,"UJCV, Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();

        }
        else if (marker.equals(markerAeropuertoToncontin)){
            String lat,lang;

            lat = Double.toString(markerAeropuertoToncontin.getPosition().latitude);
            lang = Double.toString(markerAeropuertoToncontin.getPosition().longitude);

            Toast.makeText(this,"Aeropuerto Toncontin, Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();

        }
        else if (marker.equals(markerMallMultiplaza)){
            String lat,lang;

            lat = Double.toString(markerMallMultiplaza.getPosition().latitude);
            lang = Double.toString(markerMallMultiplaza.getPosition().longitude);

            Toast.makeText(this,"Mall Multiplaza, Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();

        }
        else if (marker.equals(markerCityMall)){
            String lat,lang;

            lat = Double.toString(markerCityMall.getPosition().latitude);
            lang = Double.toString(markerCityMall.getPosition().longitude);

            Toast.makeText(this,"City Mall, Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();

        }
        else if (marker.equals(markerColKennedy)){
            String lat,lang;

            lat = Double.toString(markerColKennedy.getPosition().latitude);
            lang = Double.toString(markerColKennedy.getPosition().longitude);

            Toast.makeText(this,"Colonia Kennedy, Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();

        }
        else if (marker.equals(markerColTiloarque)){
            String lat,lang;

            lat = Double.toString(markerColTiloarque.getPosition().latitude);
            lang = Double.toString(markerColTiloarque.getPosition().longitude);

            Toast.makeText(this,"Colonia Lomas de Tiloarque, Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();

        }
        else if (marker.equals(markerColoniaMirflores)){
            String lat,lang;

            lat = Double.toString(markerColoniaMirflores.getPosition().latitude);
            lang = Double.toString(markerColoniaMirflores.getPosition().longitude);

            Toast.makeText(this,"Colonia Miraflores, Tegucigalpa, Honduras",Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();

        }
        else if (marker.equals(markerColoniaUvas)){
            String lat,lang;

            lat = Double.toString(markerColoniaUvas.getPosition().latitude);
            lang = Double.toString(markerColoniaUvas.getPosition().longitude);

            Toast.makeText(this,"Residencial Las Uvas, Tegucigalpa, Honduras", Toast.LENGTH_SHORT).show();
            Toast.makeText(this,lat + "," + lang + ",",Toast.LENGTH_SHORT).show();
        }

        return false;
    }

    @Override
    public void onMarkerDragStart(Marker marker) {

        if (marker.equals(markerDrag)) {
            Toast.makeText(this, "Inicio", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onMarkerDrag(Marker marker) {

        if (marker.equals(markerDrag)){
            String newTitle = String.format(Locale.getDefault(),
                    getString(R.string.marker_detail_latlang),
                    marker.getPosition().latitude,
                    marker.getPosition().longitude);

            setTitle(newTitle);

        }

    }

    @Override
    public void onMarkerDragEnd(Marker marker) {

        if (marker.equals(markerDrag)) {
            Toast.makeText(this, "Final", Toast.LENGTH_SHORT).show();
            setTitle(R.string.Destinos);
        }

    }
}
